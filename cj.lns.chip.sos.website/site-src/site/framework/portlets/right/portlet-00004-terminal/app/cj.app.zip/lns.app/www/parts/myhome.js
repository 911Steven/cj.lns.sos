cj.studio.mobile.myhome={
	render:function(){
		console.log('myhome');
	}
	
}