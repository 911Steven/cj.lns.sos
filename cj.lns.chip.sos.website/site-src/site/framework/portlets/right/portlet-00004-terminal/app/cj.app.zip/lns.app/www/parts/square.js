cj.studio.mobile.square={
	render:function(){
		var the=cj.studio.mobile.square;
		var tools=$('.square .me .tools');
		//$('#afui .square').on('click',function(){$('.square .center').append("<div style='margin-top:100px;'>aaaaaaa</div>");});
		tools.delegate('a[cjevent]','click',function(e){
			
			var cjevent=$(e.currentTarget).attr('cjevent');
			if(cjevent=='plus'){				
				
				tools.find('.pad .t-22').toggle();
				console.log('square');
				
			}else if(cjevent=='capture'){
				console.log('capture')
				the.tools.capture();				
			}
			
			});
			//聊天区从低往上滚动
		var publicRegion=$('#publicChatRegion');
		var myRegion=$('#myChatRegion');
		$.cj.square.scroll(publicRegion);
		$.cj.square.scroll(myRegion);
	},
	scroll:function(region){
				var myScroller = region.scroller(); 
	
		myScroller.addInfinite();
      myScroller.addPullToRefresh();
      $.bind(myScroller, 'scrollend', function () {
          console.log("scroll end");
      });
 
 
      $.bind(myScroller, 'scrollstart', function () {
         console.log("scroll start");
      });
 
 
      $.bind(myScroller, "refresh-trigger", function () {
         console.log("refresh-trigger");
         
      });
 
 
      
      $.bind(myScroller, "refresh-release", function () {
         console.log("refresh-release");            
          return true; //tells it to not auto-cancel the refresh
      });
 
 
      $.bind(myScroller, "refresh-cancel", function () {
         console.log("refresh-cancel");
      });
 
 
      $.bind(myScroller, "refresh-finish", function () {
        console.log("refresh-finish");
      });
	  myScroller.enable();
	},
	tools:{
		capture:function(){
			navigator.camera.getPicture(onSuccess, onFail, { quality: 100,
				destinationType: Camera.DestinationType.FILE_URI });
			
				function onSuccess(imageURI) {
					var img=$.create('li',{html:"<a href='#'><img style='width:100px;height:100px;' src='"+imageURI+"'/></a>"});
					//alert(imageURI);
					$(img).addClass('item');
					$('#myChatRegion ').append(img);
					$('#publicChatRegion ').append(img);
					//alert($('#publicChatRegion  > ul').html());
				}
				
				function onFail(message) {
					alert('Failed because: ' + message);
				}
			
			}
		
		}
	
}