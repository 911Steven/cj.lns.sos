cj.studio.mobile.mainNav={
	render:function(){
		$('#applicationPad').show();
		$('#mainNav .title').on('click',function(e){
			var sel=$(e.target);
			
			var parent=$(this).parents('#mainNav');
			$(this).find('.title a').removeClass('selected');
			sel.addClass('selected');
			parent.find('.box').hide();
			$('#'+sel.attr('to')).show();
			
			});
	}
	
}