cj.studio.mobile.contact={
	render:function(){
		$('#public').show();
		var tabs=$('#contactTabs');
		tabs.on('click',function(e){
			var sel=$(e.target);
			
			tabs.find('.selected').removeClass('selected');
			sel.addClass('selected');
			$('#contact').find('.tree').hide();
			$('#'+sel.attr('to')).show();
			
			});
		var tree=$('#contact > .tree');
		tree.find('li > ul').hide();
		tree.delegate('li >  a','click',function(e){
			e.preventDefault();
			var sel=$(e.target);
			var ul=sel.siblings('ul');
			ul.toggle();
			var ctr=sel.children('p');
			if($(ul).css('display')=='none'){
				ctr.css('-moz-transform','rotate(0deg)');
				$(ctr).css('-webkit-transform','rotate(0deg)');
				$(ctr).css('transform','rotate(0deg)');
				$(ctr).css('top','-8px');
			}else{
				ctr.css('-moz-transform','rotate(90deg)');
				$(ctr).css('-webkit-transform','rotate(90deg)');
				$(ctr).css('transform','rotate(90deg)');
				$(ctr).css('top','0');
			}
			});
			
		//绑定迎客亭事件
		tree.find('li > ul > li > a[cjevent]').on('click',function(e){
			var id=$(this).attr('cjevent');
			if($('#yingketing').length>0)
				$.cj.yingketing.open($('#contact'),id,'aside');
			else{
				$.cj.open('win-yingketing-1.00.000');
			}
		});
		}
		

}