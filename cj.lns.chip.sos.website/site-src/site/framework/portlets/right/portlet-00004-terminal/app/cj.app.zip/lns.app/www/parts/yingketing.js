cj.studio.mobile.yingketing={
	render:function(){
		
	},
	//opender是谁打开的，用于返回到来源页面
	open:function(container,id,opener){
		var the=$('#yingketing');
		this.update(the,id);
			$.ui.loadContent('yingketing',false,false);
			the.attr('opener',opener);
			
	},
	update:function(the,id){//在此可更新迎客亭的数据，主意：如果需要更新元素，且保证footer,header不被替换掉，否则将被默认的头替换
	
			},
	goBack:function(){
		var the=$('#yingketing');
		var opener=the.attr('opener');
		//debugger;
		if(!opener){
			$.ui.goBack();
			return;	
		}
		if(opener=='aside'){			
			$.cj.backDesktop();
			$.ui.toggleRightSideMenu();	
			the.attr('opener','');
			return ;
		}
		$.ui.goBack();
		the.attr('opener','');
	}
}