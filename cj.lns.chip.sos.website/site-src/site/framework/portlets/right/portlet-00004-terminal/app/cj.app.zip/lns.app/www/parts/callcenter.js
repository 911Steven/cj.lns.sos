cj.studio.mobile.callcenter={
	render:function(){
								
		this.getServicePlatForm=function(data){$.cj.callcenter.config=data;};
		$.jsonP({url:'protocol/servicePlatform/partWorld.json?callback=getServicePlatForm'});
		
		//debugger;
		this.scroll($("#dealPad"));
		this.scroll($("#callcenter .callcenter > .status >.s-2"));
	},
	scroll:function(region){
		var myScroller = region.scroller(); 
	
		myScroller.addInfinite();
      myScroller.addPullToRefresh();
      $.bind(myScroller, 'scrollend', function () {
          console.log("scroll end");
      });
 
 
      $.bind(myScroller, 'scrollstart', function () {
         console.log("scroll start");
      });
 
 
      $.bind(myScroller, "refresh-trigger", function () {
         console.log("refresh-trigger");
         
      });
 
 
      
      $.bind(myScroller, "refresh-release", function () {
         console.log("refresh-release");            
          return true; //tells it to not auto-cancel the refresh
      });
 
 
      $.bind(myScroller, "refresh-cancel", function () {
         console.log("refresh-cancel");
      });
 
 
      $.bind(myScroller, "refresh-finish", function () {
        console.log("refresh-finish");
      });
	  myScroller.enable();	
	}
	
}