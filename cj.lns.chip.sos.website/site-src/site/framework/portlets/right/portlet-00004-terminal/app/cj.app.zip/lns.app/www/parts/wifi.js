cj.studio.mobile.wifi={
	render:function(){
		console.log('wifi');
	}
	
}