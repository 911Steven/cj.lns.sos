cj.studio.mobile.publicPlatform={
	render:function(){
		
	},
	toggleServicePad:function(){
		var pads=$("  .servicePad");
		pads.css('bottom',$('#navbar').css('height'));
		var tabs=$("  .servicePad >.serviceTabs");
		pads.toggle();
		tabs.delegate('a[cjevent]','click',function(e){
			var  t=$(e.currentTarget);
			var pad=t.attr('cjevent');
			var prevSel=tabs.find('.selected');
			prevSel.removeClass('selected');
			t.addClass('selected');
			var prevPad=prevSel.attr('cjevent');
			//debugger;
			pads.find(".container >div[tab='"+prevPad+"']").hide();
			pads.find(".container >div[tab='"+pad+"']").show();
			});
	},
	showFilter:function(the){
		$("#afui").actionsheet(
                            [{
                                text: '全部',
                                cssClasses: 'red',
                                handler: function () {
                                   $(the).parent().siblings("a[name='selected']").text("全部");
                                }
                            }, {
                                text: 'XX地店',
                                cssClasses: 'blue',
                                handler: function () {
                                    $(the).parent().siblings("a[name='selected']").text("XX地店");
                                }
                            }, {
                                text: 'XX广场',
                                cssClasses: '',
                                handler: function () {
                                  $(the).parent().siblings("a[name='selected']").text("XX广场");
                                }
							
                            }, {
                                text: 'XX网店',
                                cssClasses: '',
                                handler: function () {
                                    $(the).parent().siblings("a[name='selected']").text("XX网店");
                                }
							
							}, {
                                text: 'XX公网',
                                cssClasses: '',
                                handler: function () {
                                     $(the).parent().siblings("a[name='selected']").text("XX公网");
                                }
							
							}, {
                                text: '地理微博',
                                cssClasses: '',
                                handler: function () {
                                     $(the).parent().siblings("a[name='selected']").text("XX地店");
                                }
							
							}, {
                                text: '地圈活动',
                                cssClasses: '',
                                handler: function () {
                                     $(the).parent().siblings("a[name='selected']").text("地圈活动");
                                }
							
							}, {
                                text: '联盟活动',
                                cssClasses: '',
                                handler: function () {
                                     $(the).parent().siblings("a[name='selected']").text("联盟活动");
                                }
							
							}]);	
	}
}