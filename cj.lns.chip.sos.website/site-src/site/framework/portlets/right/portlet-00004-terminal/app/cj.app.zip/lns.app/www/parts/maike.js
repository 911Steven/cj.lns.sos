cj.studio.mobile.maike={
	render:function(){
		console.log('maike');
	}
	
}