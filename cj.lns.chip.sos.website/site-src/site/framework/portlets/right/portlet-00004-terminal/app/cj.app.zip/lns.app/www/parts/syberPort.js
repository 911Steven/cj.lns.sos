cj.studio.mobile.syberPort={
	render:function(){
		
		//绑定迎客亭事件
		var msgHead=$('#afui .head');
		msgHead.find('a[cjevent]').on('click',function(e){
			var id=$(this).attr('cjevent');
			$.cj.open('win-yingketing-1.00.000');
			//cj.studio.mobile.yingketing.open($('#desktop'),id,'desktop');
		});
		
		var pad=$('#afui #syberPort .syberPort .view_henglie');
		pad.find('.henglie_list').on('click',function(e){
			$(this).parent().siblings('.personList').toggle();
		});
		
		var msg=$('#syberPort .syberPort .appList .appPad .personList ');
		msg.find('.personMsg[cjevent]').on('click',function(e){
			
			var events=$(this).attr('cjevent');
			console.log(events);
			var arr=events.split('#');
			if(arr[0]=='chat'){
				$.cj.open('win-chat-1.00.000');
			}else if(arr[0]=='diliweibo'){
				$.cj.open('sys-diliweibo-1.00.000');
			}else if(arr[0]=='fuwutai'){
				$.cj.open('sys-callcenter-1.00.000');
			}
			
		});
		
	var myScroller = $("#syberPort").scroller(); 
	
	myScroller.addInfinite();
      myScroller.addPullToRefresh();
      $.bind(myScroller, 'scrollend', function () {
          console.log("scroll end");
      });
 
 
      $.bind(myScroller, 'scrollstart', function () {
         console.log("scroll start");
      });
 
 
      $.bind(myScroller, "refresh-trigger", function () {
         console.log("refresh-trigger");
         
      });
 
 
      
      $.bind(myScroller, "refresh-release", function () {
         console.log("refresh-release");            
          return true; //tells it to not auto-cancel the refresh
      });
 
 
      $.bind(myScroller, "refresh-cancel", function () {
         console.log("refresh-cancel");
      });
 
 
      $.bind(myScroller, "refresh-finish", function () {
        console.log("refresh-finish");
      });
	  myScroller.enable();
	}
}