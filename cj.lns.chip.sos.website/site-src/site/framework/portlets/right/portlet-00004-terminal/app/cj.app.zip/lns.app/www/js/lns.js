//插件定义
(function($){
    $.fn.flyGo=function( e){//消息飞入动画
		
    };
	
})(af);


var cj={};
cj.studio={};
cj.studio.mobile={
	event:{},
	deskMap:[],
	panels:[],
	//设备状态，1表示已准备好，0是已初始化环境变量，－1是dom已加载完成，
	deviceState:0,
	lnsEnvFiles:{
		env:'protocol/device.json',
		panelsDef:'protocol/panelsDefinition.json'
		},
		
		desktop:{
			current:'desktop',
			main:'desktop'	,
			//重置桌面，作用：让历史返回到系统或应用的桌面为止。
			resetDesk:function(el){
				$.ui.firstDiv=el.get(0);
				$.ui.clearHistory();	
			}
	},
	//对象id，系统和应用.a表示应用 :a-桌面id-版本号 s表示系统 :s-桌面id-version，
	//默认是加载一次	,如果即设置了刷新又设置了加载一次，则刷新优先	
	open:function(zoid,persist,refresh,trans){
		
		var rule=/sys.+|app.+/;
		var panelDef={isSysOrApp:false};//panel的定义
		if(rule.test(zoid)){
			var found=this.findPanelOid(zoid);
			if(!found){
				console.error('系统或应用不存在指定的panel映射定义deskMap.标识：'+zoid);	
				return;
			}
			panelDef.panelOid=found;
			found=this.findPanelDefinition(found);
			if(!found){
				console.error('在panel定义中未找到与系统或应用标识匹配的panel，标识：'+zoid);
				return;	
			}
			panelDef.found=true;
			panelDef.panelDef=found;
			panelDef.isSysOrApp=true;
		}else{
			var found=this.findDefinition(zoid);
			if(!found){
				console.error('系统oid不存在指定的panel映射定义.'+zoid);	
				return;
			}
			panelDef=found;
			panelDef.found=true;
		}
		if(!panelDef.found){
			console.error('不能打开指定的oid，因为它的定义不完整。'+zoid);
			return;
		}
		var arr=panelDef.panelOid.split('-');
		if(arr.length<2||arr.length>3)console.error('oid错误');
			
		var the=this;
		/*if($.ui.history.length>0){
			$.ui.history.length=0;
		}*/
		//$.cj.clearContent(panelDef.panelDef.panelId);
		var panel=$('#'+panelDef.panelDef.panelId);
		if(panel.length>0){
			if(refresh=='true'){//更新
				this.updateToPanel(panelDef.panelDef,panel,function(){
					$.ui.loadContent('#'+panelDef.panelDef.panelId,true,false,trans);
					if(panelDef.isSysOrApp){
						$.cj.desktop.current=panelDef.panelDef.panelId;
						$.cj.desktop.resetDesk(panel);
						$('#afui').trigger('deskChanged',$.cj.desktop);
					}
					//jqmobi转场时会将当前场的头重新再添加到panel中，如果此时panel被更新了内联的头和脚，则会重复，因此去掉
					$('#'+panelDef.panelDef.panelId).find('header').remove();
					$('#'+panelDef.panelDef.panelId).find('footer').remove();
					});					
				return;
			}
			if(persist=='true'){//转场即可
				$.ui.loadContent('#'+panelDef.panelDef.panelId,false,false,trans);
				if(panelDef.isSysOrApp){
						$.cj.desktop.current=panelDef.panelDef.panelId;
						$.cj.desktop.resetDesk(panel);
						$('#afui').trigger('deskChanged',$.cj.desktop);
					}
				return;
			}
			//最后，如果啥都没指定就默认转场
			$.ui.loadContent('#'+panelDef.panelDef.panelId,false,false,trans);
			if(panelDef.isSysOrApp){
						$.cj.desktop.current=panelDef.panelDef.panelId;
						$.cj.desktop.resetDesk(panel);
						$('#afui').trigger('deskChanged',$.cj.desktop);
					}
		}else{//不论是刷不刷都得新建
			$.cj.createPanel(panelDef.panelDef,function(el){
				$.ui.loadContent('#'+panelDef.panelDef.panelId,true,false,trans);
					if(panelDef.isSysOrApp){
						$.cj.desktop.current=panelDef.panelDef.panelId;
						$.cj.desktop.resetDesk(el);
						$('#afui').trigger('deskChanged',$.cj.desktop);
					}
					//jqmobi转场时会将当前场的头重新再添加到panel中，如果此时panel被更新了内联的头和脚，则会重复，因此去掉
					$('#'+panelDef.panelDef.panelId).find('header').remove();
					$('#'+panelDef.panelDef.panelId).find('footer').remove();
				});										
		}		
		
	},
	stop:function(oid){
		
	},
	findPanelOid:function(oid){
		var found;
		$(this.deskMap).each(function(index, e) {
            if(e.who==oid){
				found=e.has;
				return false;	
			}
        });
		return found;
	},
	findPanelDefinition:function(oid){
		var found;
		$(this.panels).each(function(index, e) {
            var the=e.type+'-'+e.panelId+'-'+e.version;
			if(the==oid){
				found=e;
				return false;
			}
        });
		return found;
	},
	findDefinition:function(oid){
		var ret={panelOid:oid};
		var found=this.findPanelOid(oid);
		if(found){
			ret.panelOid=found;	
			ret.isSysOrApp=true;
		}
		found=this.findPanelDefinition(ret.panelOid);	
		if(found){
			ret.panelOid=found.type+'-'+found.panelId+'-'+found.version;
			ret.panelDef=found;
			return ret;
		}
	},
	direxecPartScript:function(ep){//直接执行
		//var whole=script.attr('src');
			//var ep=whole;//.substring(whole.indexOf('?'),whole.lenght);
			//console.log(ep);
			//debugger;
			//var test=/^\?.*entryPoint\s*=\s*(\S+)/;
			//var ret=test.exec(ep);
			//ep=ret[1];
			var arr=ep.split('.');
			var tmp=window.cj;
			for(var i=1;i<arr.length;i++){
				tmp=tmp[arr[i]];
				if(!tmp)break ;
			}
			if(!tmp){
			console.error('脚本还没有完成加载便执行部件的render方法。可能和缓冲有关，也可能是异步加载问题');
			return
			}
			if(typeof tmp.render!='function')
			console.error('部件缺少render方法，请实现。'+ep);
			tmp.render();
	},
	//已过期不用　 
	execPartScript:function(script){
		script.on('load', function() {//脚本加载完成后执行初始化方法
			var whole=script.attr('src');
			var ep=whole.substring(whole.indexOf('?'),whole.lenght);
			//console.log(ep);
			
			var arr=ep.split('.');
			var tmp=window.cj;
			for(var i=1;i<arr.length;i++){
				tmp=tmp[arr[i]];
				if(!tmp)break ;
			}
			tmp.render();
			});

		
		
	}
};

//准备环境
cj.studio.mobile.prepareEvn=function(){
		    	//以下获取桌面配置	
	 var req=$.ajax({
        async:false,
		dataType: "json",
		url: intel.xdk.webRoot + cj.studio.mobile.lnsEnvFiles.env,
		success: function(d) {
			cj.studio.mobile.deskMap=d.deskMap;
			cj.studio.mobile.defaultSys=d.defaultSys;
			cj.studio.mobile.demandSignin=d.demandSignin=='true'?true:false;           
		},
		error: function(msg) {
		   console.log(msg);
		}
	});	 
	 $.ajax({
         async:false,
		 dataType: "json",
		url: intel.xdk.webRoot + cj.studio.mobile.lnsEnvFiles.panelsDef,
		success: function(data) {
			cj.studio.mobile.panels=data;
		},
		error: function(msg) {
		   console.log(msg);
		}
	});	 
	
	cj.studio.mobile.deviceState=0;
}
//以下初始化环境，此函数保障在所有装载前完成
cj.studio.mobile.prepareEvn();

cj.studio.mobile.createPanel=function(panelDef,callback){
	var oid=panelDef.type+'-'+panelDef.panelId+'-'+panelDef.version;
	var loadPart=$.cj.loadPart;
	if(panelDef.inline=='true'){
		loadPart($('#afui #content'),panelDef['data-defer'],function(ctr,data){
			//debugger;
			var newDiv=$.create("div", {
				html:data
				});
			if (newDiv.children(".panel") && newDiv.children(".panel").length > 0) newDiv = newDiv.children(".panel").get(0);
            else newDiv = newDiv.get(0);			
			$.ui.addContentDiv(panelDef.panelId,newDiv.innerHTML);
			$.cj.panelDefToPanelE(panelDef,$('#'+panelDef.panelId));	
			//新载入是否会自动向head添加script？如果不自动就需要在其后写添加脚本代码，见updateToPanel方法
			$.cj.updateScript(panelDef);
			if(callback)
			callback($('#'+panelDef.panelId));
		});
	}else{		
		loadPart(null,panelDef['data-defer'],function(ctr,data){
			$.ui.addContentDiv(panelDef.panelId,data);
			el=$('#'+panelDef.panelId);
			$.cj.panelDefToPanelE(panelDef,el);
			$.cj.updateScript(panelDef);
			if(callback)
			callback(el);
		});
	}
};
cj.studio.mobile.isEmpty=function(str){
	if(!str)return true;
	else if(str==null)return true;
	else if(str=='')return true;
	else
	return false;
}
cj.studio.mobile.panelDefToPanelE=function(panelDef,pandEl){
	if($.cj.isEmpty(panelDef.type)||$.cj.isEmpty(panelDef.panelId)||$.cj.isEmpty(panelDef.version))
	{console.log("panel定义错误：类型、标识、版本是必须字段。");return;}
	var oid=panelDef.type+'-'+panelDef.panelId+'-'+panelDef.version;
	if(!panelDef['data-footer']&&panelDef['data-footer']==null){
		panelDef['data-footer']='';		
	}	
	if(panelDef['data-header']==null){
		panelDef['data-header']='';		
	}
	if(panelDef['data-nav']==null){
		panelDef['data-nav']='';		
	}
	if(panelDef['data-aside']==null){
		panelDef['data-aside']='';		
	}
	if(panelDef['selected']==null){
		panelDef['selected']='';		
	}
	if(panelDef['data-tab']==null){
		panelDef['data-tab']='';		
	}
	if(panelDef['modal']==null){
		panelDef['modal']='';		
	}
	if(panelDef['data-load']==null){
		panelDef['data-load']='';		
	}
	if(panelDef['data-unload']==null){
		panelDef['data-unload']='';		
	}
	
	pandEl.attr('data-bind',oid);	
	pandEl.attr('data-footer',panelDef['data-footer']);
	pandEl.attr('data-header',panelDef['data-header']);
	pandEl.attr('data-nav',panelDef['data-nav']);
	if(!$.cj.isEmpty(panelDef['data-aside'])&&panelDef['data-aside'].indexOf('#')>-1){
		$.cj.loadAside(pandEl,panelDef['panelId'],panelDef['data-aside'].substring(1));
	}else{
	pandEl.attr('data-aside',panelDef['data-aside']);
	}
	pandEl.attr('selected',panelDef['selected']);
	pandEl.attr('data-tab',panelDef['data-tab']);
	pandEl.attr('modal',panelDef['modal']);
	pandEl.attr('data-load',panelDef['data-load']);
	pandEl.attr('data-unload',panelDef['data-unload']);
}
cj.studio.mobile.loadAside=function(pandEl,panelId,path){
	$.ajax({
		url: intel.xdk.webRoot + path,
		success: function(data) {
			//debugger;
			var newAside=$.create('div',{html:data});
			newAside=$(newAside).find('aside');
			if(newAside.length<1){
					newAside=$.create('aside',{html:data});	
					$(newAside).attr('id','aside_'+panelId);
 			}else{
				if(newAside.length>1){
					console.error('代码中定义了多个aside.'+path);
					return;
				}				
			}
			$('#afui').append(newAside);
			pandEl.attr('data-aside',$(newAside).attr('id'));
			$.ui.updateAsideElements(newAside);
		},
		error: function(msg) {
		   console.log(msg);
		}
	});
}
cj.studio.mobile.clearContent=function(panelId){
	var p=$('#'+panelId);
	$("#afui header[data-parent='"+panelId+"']").remove();
	$("#afui footer[data-parent='"+panelId+"']").remove();
	p.remove();
	if($.ui.history.length>0){
			$.ui.history.length=0;
		}
	var newDiv=$.create("div",{html:"<div class='panel' style='display:none'></div>"});
	$.ui.activeDiv=$(newDiv).children().get(0);
	if($.ui.prevHeader)
	$.ui.prevHeader.empty();
	if($.ui.prevFooter)
	$.ui.prevFooter.empty();
}
cj.studio.mobile.updateScript=function (panelDef){
		//更新了panel需要重新绑定事件，因此将脚本重新render一下，以使用户render方法中绑定的事件重新生效						
		var sel=$("script[src*='"+panelDef['data-defer'].replace('.html','.js')+"']");						
		if(sel.length>0)	{				
				var n=$.create("script", {
				src: sel.attr('src')
				});
				sel.remove();						
				$('head').append(n);//向head中添加脚本会触发dom事件，先前lns已侦听了该事件用于脚本扫描
			
		}	
}
cj.studio.mobile.desktop.clearHeaderAndFooter=function(id){
	//此下处理切换桌面时头和脚转场重复插入问题。原理：jqmobi的$.ui.prevHeader用来转头，在转之前将之前的父id为当前panel的从dom中移除，并重置该属性
	if($.ui.prevHeader){
		var prev=$.ui.prevHeader;				
		if (!$.is$prev){
			var tt=$('#afui').find("header[data-parent='"+id+"']");						
				tt.remove();
			if(prev.attr('data-parent')==id){						
				tt.empty();						
				$.ui.prevHeader=tt;
			}
		}
	}
	if($.ui.prevFooter){
		var prev=$.ui.prevFooter;				
		if (!$.is$prev){
			var tt=$('#afui').find("footer[data-parent='"+id+"']");						
				tt.remove();
			if(prev.attr('data-parent')==id){
				tt.empty();						
				$.ui.prevFooter=tt;
			}
		}
	}
}
cj.studio.mobile.updateToPanel=function(panelDef,pandEl,callback){
	
	$.cj.panelDefToPanelE(panelDef,pandEl);	
	
	//var oid=panelDef.type+'-'+panelDef.panelId+'-'+panelDef.version;
	if(panelDef.inline=='true'){//是内联则添加到容器后再更新到pandEl
		$.cj.loadPart($('#afui #content'),panelDef['data-defer'],function(ctr,data){
			var newDiv=$.create("div", {
				html:data
				});
			if (newDiv.children(".panel") && newDiv.children(".panel").length > 0) newDiv = newDiv.children(".panel").get(0);
            else newDiv = newDiv.get(0);
			//debugger;
			if($.ui.activeDiv&&$($.ui.activeDiv).attr('id')===pandEl.attr('id'))
				$.ui.activeDiv=newDiv;//jqmobi中，如果当前场为要转的场，则不转场，因此如果想更新桌面并转场，则需要重置它的前场为非要转的场。此处是将当前场设为panel，以欺骗jqmobi
			var id=pandEl.attr('id');
			$.cj.desktop.clearHeaderAndFooter(id);
			$.ui.updatePanel('#'+$(pandEl).attr('id'),newDiv.innerHTML);
			
			if(cj.studio.mobile.deviceState==1){//设备准备好之后再触发，因为之前由head事件处理脚本为免重复
				$.cj.updateScript(panelDef);
			}				
			if(callback)
			callback();			
		});
	}else{
		$.cj.loadPart(null,panelDef['data-defer'],function(ctr,data){			
			//pandEl.html(data);//一定得用$.ui.updatePanel因为它会加上滚动条，否则无滚动条
			//由于元素中前次加载时jqmobi会在元素中保留头和脚，并为之添加data-parent元素，如果不移除，如果更新源中带有头和脚，则头和脚将重复添加
			//因此，更新前应把先前加载的头和脚移除，在转场时jqmobi将重新解释新脚和头
			$(pandEl).find('header[data-parent]').remove();
			$(pandEl).find('footer[data-parent]').remove();
			$.ui.updatePanel('#'+$(pandEl).attr('id'),data);//容中有头和脚会加在afui的头部和脚部，因此每次更新须去掉。但是如果要转的场景是当前场景，则转场函数并不执行转场
			
			if(cj.studio.mobile.deviceState==1){
				//debugger;
				$.cj.updateScript(panelDef);//设备准备好之后再触发，因为之前由head事件处理脚本,为免重复
			}	
			if(callback)
				callback();							
		});
	}
				
}
cj.studio.mobile.goDefaultSystem=function(){
	$.cj.open($.cj.defaultSys);
}
cj.studio.mobile.backMain=function(trans){
	$.ui.loadContent('#'+$.cj.desktop.main,false,false,trans);	
	$.cj.desktop.current=$.cj.desktop.main;
	$.cj.desktop.resetDesk($('#'+$.cj.desktop.main));
	$('#afui').trigger('deskChanged',$.cj.desktop);
}
cj.studio.mobile.backDesktop=function(trans){
	$.ui.loadContent('#'+$.cj.desktop.current,false,false,trans);	
}
cj.studio.mobile.loadPart=function(e,url,callback){
	$.ajax({
		url: intel.xdk.webRoot + url,
		success: function(data) {
			//console.log(data);
			//debugger;
			if(callback){
			callback(e,data);
			return;
			}						
			e.html(data);			
			
		},
		error: function(msg) {
		   console.log(msg);
		}
	});
}

cj.studio.mobile.updateContent=function(){//在设备准备好后执行该方法
	var demand=$("#afui #content .panel[data-bind*='-']");
	demand.each(function(index, e) {
		var oid=$(e).attr('data-bind');
		var found;
		$($.cj.panels).each(function(index, p) {
			var poid=p.type+'-'+p.panelId+'-'+p.version;
            if(poid==oid){				
				$.cj.updateToPanel(p,$(e),null);
				console.log('发现可绑定panel:'+oid+'，现进行绑定');
				found=true;
				return found;
			}
        });
    });
	
}
cj.studio.mobile.scanPanels=function(){
	//1.先对afui中已存在的panel使用定义的panel对之初始化
	var mobile=this;
	if(!mobile.defaultSys||mobile.defaultSys==''){
		console.error('没有指定默认系统');
	}
	var deskOid=mobile.findPanelOid(mobile.defaultSys);
	if(!deskOid)
	console.error('系统没有映射桌面'+mobile.defaultSys);
	 var deskDef=mobile.findPanelDefinition(deskOid);
	if(!deskDef)
	console.error('没有定义panel:'+deskOid);
	desk=$('#'+deskDef.panelId);
	if(desk.length<1){
		var newDiv=$.create('div',{html:"<div id="+deskDef.panelId+" class='panel' data-bind='"+deskOid+"'></div>"});
		$('#afui $content').append(newDiv.children().get(0));
		desk=	$('#'+deskDef.panelId);
	}else{
		if(!desk.attr('data-bind'))
			desk.attr('data-bind',deskOid);
	}
	mobile.desktop.current=deskDef.panelId;
	mobile.desktop.main=deskDef.panelId;
	
	if(!$.cj.demandSignin){			
		$("#afui #content .panel[selected='true']").removeAttr('selected');
		$('#'+deskDef.panelId).attr('selected','true');
		deskDef.selected='true';
	}
	
	var els=$('#afui #content .panel');
	
	$(els).each(function(index, el) {
        var id=$(el).attr('id');
		var dbind=$(el).attr('data-bind');
		if(!dbind)return true;//只绑定指定dbbind的
		var defer=$(el).attr('data-defer');//有defer属性则不采用绑定机制
		if(defer)
		{console.warn("警告："+id+"的panel已绑定了data-defer属性，data-bind失效");return true;}
		$(mobile.panels).each(function(index, p) {
			var oid=p.type+'-'+p.panelId+'-'+p.version;
            if(oid===dbind){
				if(id!==p.panelId){
					console.log('panel定的id不一致，将覆盖panel的id。'+oid+':'+id+"!="+p.panelId);	
					$(el).attr('id',p.panelId);
				}
				mobile.panelDefToPanelE(p,$(el));	//扫描中只更新属性，不赋内容，之后按需获取，以节点内存				
				return false;
			}
			
        });		
    });
	
	
};
//初始化在文档装载完时发生，主要是panel的扫描，更早期的事件绑定等
cj.studio.mobile.onInit = function () { 
	var mobile=cj.studio.mobile;	//装载边栏
       var elnav=$('#afui nav[data-defer]');
	   var elaside=$('#afui  aside[data-defer]');	   
	 elnav.each(function(index, e) {
		cj.studio.mobile.loadPart($(e),$(e).attr('data-defer'));
	 	});
	 elaside.each(function(index, e) {
		cj.studio.mobile.loadPart($(e),$(e).attr('data-defer'));
	 });
	mobile.scanPanels();//扫描并附加定义，只能放到这干活了，因为jqmobi在DOMContentLoaded事件中加载panel并转场，如果也在此事件下初始化系统，则会存在两者争用，或者它先或者它后，导致默认桌面装载不了。
	
	 //打开默认系统
	 //mobile.desktop.init();
	 /*扩展<a标签：
	 	1.必须指定两个属性：data-id='panelId' data-defer='要加载的页面地址'。使用时必须将超连接的href='#'，即不设定值，这是为了避免jqmobi对超链接的处理逻辑
		2.inline＝true是内联。内联是指将定义的panel文件装载进去，此文件必须有panel的完整定义，如果只是定义了panel的内容，则不能使用内联，默认为非内联方式。
		3.data-refresh-ajax＝true是每请求都加载文件
		4.data-persist-ajax＝true是只加载一次文件，之后的请求都使用历史。
		*/
	 af.query("#afui").on("click", "a", function(e) {	
	 //$('#afui').delegate('a[data-oid]','click',function(e){	
			var loadPart=cj.studio.mobile.loadPart;
			var a=$(e.currentTarget);
			var oid=a.attr('data-bind');//为什么不用href属性作为转换目标？因为该事件已被jqmobi使用，在未处理你的代码前就已按jqmobi的机制转场了，所以再删除pannel后再添加会乱
			
			//debugger;
			 if(oid&&oid!=null&&oid!=''){				 					
					var el=$('#afui #content #'+oid);	
					var persist=a.attr('data-persist-ajax');
					var refresh=a.attr('data-refresh-ajax');
					var trans=a.attr('data-transition');
					console.log('open '+oid+' '+persist+' '+refresh+' '+trans);	
					if ($.ui.isSideMenuOn()) $.ui.toggleSideMenu(false);	
					mobile.open(oid,persist,refresh,trans);
					
				}
				
            });
	mobile.deviceState=-1;
    };

if(cj.studio.mobile.demandSignin){	
document.addEventListener("DOMContentLoaded", function(){
		$("#afui #content .panel[selected='true']").removeAttr('selected');
		$('#login').attr('selected','true');		
		}, false);
}else{		
document.addEventListener("DOMContentLoaded", cj.studio.mobile.onInit, false);
}
//原理：部件的脚本会被自动添加到头部，因此在头部捕捉脚本装载完毕的事件
cj.studio.mobile.onScriptLoad=function(e){
	var s=$(e.target).get(0);
	var d=$(e.relatedNode).get(0);
	var test=/\S+\?entryPoint=(\S+)/;
	
	if(d.tagName.toUpperCase()=='HEAD'&&s.tagName.toUpperCase()=='SCRIPT'){	
		var src= $(s).attr('src').replace('%20').replace(' ','');
		var hit=test.test(src);
		if(!hit&&src.indexOf('entryPoint')>0){
			console.error('错误的脚本定义，入口点格式错误：'+src);
			return;
		}
		if(!hit)return;
		var ep=test.exec($(s).attr('src'));
		if(ep==null){
			console.error('错误的脚本定义，或者没有定义入口点：'+src);
			return;
		}
		$(s).on('load',function(the){			
			cj.studio.mobile.direxecPartScript(ep[1]);
		});
	}
}
document.addEventListener('DOMNodeInserted',cj.studio.mobile.onScriptLoad,false);
//初始化afui环境，并加载默认桌面
cj.studio.mobile.onReady=function(){
	
	var mobile=cj.studio.mobile;
		
	mobile.updateContent();	
	
	if(!$.cj.demandSignin){
		var selected=$("#afui #content .panel[selected='true']");
		//debugger;
		if(selected.length>0){
			selected=$(selected.get(0));
				
				var bind=selected.attr('data-bind');
				if(bind&&bind!=''){
					//jqmobi在初始加载时时因为因为我做了panel的更新没有转场因而解释为空，而且当前场景就是选中的场景，因此折衷办法是创建新的panel，然后再转回来
					var newDiv=$.create("div", {
						html:"<div class='panel'></div>"
						});
					if (newDiv.children(".panel") && newDiv.children(".panel").length > 0) newDiv = newDiv.children(".panel").get(0);
					else newDiv = newDiv.get(0);	
					$.ui.activeDiv=newDiv;
					mobile.open(bind);
				}
			mobile.desktop.resetDesk(selected);
		}else{//没有则使用lns的默认桌面
			mobile.open(mobile.defaultSys);
		}
	}else{
		
	}
	mobile.deviceState=1;
}
cj.studio.mobile.setup=function(callback){//外部执行初始化操作
	if(callback)
	$.cj.event.lnsready=callback;
}
$.ui.ready(
	function(){
		if(!$.cj.demandSignin){
		if($.cj.event.lnsready)$.cj.event.lnsready();
		$.cj.onReady();
		}else{
			if($.cj.event.lnsready)$.cj.event.lnsready();
			//debugger;
			if($.ui.activeDiv&&$($.ui.activeDiv).attr('id')!='login'){
				$.ui.loadContent('#login',false,false);	
			}
		}
		$('#afui').on('deskChanged',function(e,d){console.log('deskChanged:'+d.current);});
	}
);
cj.studio.mobile.start=function(){
	$.cj.onInit();
	$.cj.onReady();
	$.cj.goDefaultSystem();
}
cj.studio.mobile.initScreen=function(){//用于初始化边栏
	var plat;
	var max=312;
	var width=$("#afui").width()>(max+30)?max:$("#afui").width()-30;
	if(navigator&&navigator.platform!='undefined'){
	 plat= navigator.platform;
		if(plat=='MacIntel'||plat=='Win32'||screen.availWidth>760){//is browser，则不设置.目前在pad浏览器上旋转还不能自动算出布局，这是因为加了screen.availWidth>760
			$.ui.setLeftSideMenuWidth(width);//但这种算法也有问题，就是屏不会随道浏览器缩放而自动算对位置，而是出现混乱。只采用任何算法是最好的
			$.ui.setRightSideMenuWidth(width);
		}else if(plat=='pad'){//屏幕大就不设置
		
		}else{//是手机就设置
			$.ui.setLeftSideMenuWidth($("#afui").width()-30);//这样做当屏放大就乱了
			//设置左边菜单的宽度为 整个页面的宽度减去50px;
			$.ui.setRightSideMenuWidth($("#afui").width()-30);
		}
		//screen.availWidth - 可用的屏幕宽度
		//screen.availHeight - 可用的屏幕高度
		
	}
	
}
$.cj=cj.studio.mobile;//简化