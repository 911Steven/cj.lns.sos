cj.studio.mobile.squareAside={
	render:function(){
		var serv=$('#services');
		serv.delegate('a[cjevent]','click',function(e){
			var id=$(e.currentTarget).attr('cjevent');
			var name=$(e.currentTarget).find('span').text();
			$('#selectUser').html(name);
			$.ui.toggleRightSideMenu();
			});
	}
}