cj.studio.mobile.callcenterAside={
	render:function(){
		this.scroll($("#myTran"));
		this.scroll($("#commonTran"));
		this.scroll($("#otherTran"));
		this.selectTran();
		this.openOtherTran();
		this.record();
	},
	record:function(){
		$(".pad").delegate("a[cjevent='record']",'click',function(e){
			// capture callback
			
			var captureSuccess = function(mediaFiles) {
				var i, path, len;
				var sources='';
				for (i = 0, len = mediaFiles.length; i < len; i += 1) {
					path = mediaFiles[i].fullPath;
					// do something interesting with the file
					//sources+="<source src='"+path+"' />";
				}
				var html="<a id='dovideo' href='#' style='font-size:15px;padding:10px;'>播放</a><br/>";
				 html+="<video id='video'    style='width:100%;height:100%;' >";
				 html+="<source src='"+path+"' type='video/mp4'>";
				html=html+"</video>";
				$('.callcenter .service').html(html);
				$('#dovideo').on('click',function(){
					var video = document.getElementById("video");
					video.load();
					video.play();
					});
				$.ui.toggleRightSideMenu();
			};
			
			// capture error callback
			var captureError = function(error) {
				navigator.notification.alert('Error code: ' + error.code, null, 'Capture Error');
			};
			
			// start video capture
			navigator.device.capture.captureVideo(captureSuccess, captureError, {limit:100000});		});
	},
	toggleServicePad:function(){
		var pads=$(".ccAside >.servicePad");
		var tabs=$(".ccAside >.servicePad >.serviceTabs");
		pads.toggle();
		tabs.delegate('a[cjevent]','click',function(e){
			var  t=$(e.currentTarget);
			var pad=t.attr('cjevent');
			var prevSel=tabs.find('.selected');
			prevSel.removeClass('selected');
			t.addClass('selected');
			var prevPad=prevSel.attr('cjevent');
			//debugger;
			pads.find(".container >div[tab='"+prevPad+"']").hide();
			pads.find(".container >div[tab='"+pad+"']").show();
			});
	},
	openOtherTran:function(){
		var center=$('.ccAside >.center');
		var commonTran=center.find('.commonTran');
		var otherTran=center.find('.otherTran');		
		var tabs=$('.ccAside >.center >.tabs');
		var the=this;
		commonTran.delegate(".item[cjevent='open']",'click',function(e){
			var t=$(e.currentTarget);
			var args=t.attr('cjargs').split(',');
			var ot=tabs.find("a[cjevent='otherTran']");
			ot.html(args[1]);
			ot.css('display','inline-block');
			the.updateCommonEle(args[0]);
			
			var sel=tabs.find('.selected');
			var div=sel.attr('cjevent');
			center.find("."+div).css('display','none');
			sel.removeClass('selected');
			ot.addClass('selected');
			otherTran.css('display','block');
		});
	},
	updateCommonEle:function(id){
		console.log('update other tran:'+id);
	},
	selectTran:function(){
		var center=$('.ccAside >.center');
		var tabs=$('.ccAside >.center >.tabs');
		tabs.delegate('a[cjevent]','click',function(e){
			//debugger;
			var t=$(e.currentTarget);
			var sel=tabs.find('.selected');
			var div=sel.attr('cjevent');
			center.find("."+div).css('display','none');
			sel.removeClass('selected');
			t.addClass('selected');
			center.find("."+t.attr('cjevent')).css('display','block');
			});
	},
	scroll:function(region){
		var myScroller = region.scroller(); 	
		myScroller.addInfinite();
      	myScroller.addPullToRefresh();
      $.bind(myScroller, 'scrollend', function () {
          console.log("scroll end");
      });
 
 
      $.bind(myScroller, 'scrollstart', function () {
         console.log("scroll start");
      });
 
 
      $.bind(myScroller, "refresh-trigger", function () {
         console.log("refresh-trigger");
         
      });
 
 
      
      $.bind(myScroller, "refresh-release", function () {
         console.log("refresh-release");            
          return true; //tells it to not auto-cancel the refresh
      });
 
 
      $.bind(myScroller, "refresh-cancel", function () {
         console.log("refresh-cancel");
      });
 
 
      $.bind(myScroller, "refresh-finish", function () {
        console.log("refresh-finish");
      });
	  myScroller.enable();	
	}
	
}