cj.studio.mobile.dongke={
	render:function(){
		console.log('dongke');
	}
	
}