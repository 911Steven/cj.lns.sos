cj.studio.mobile.profile={
	render:function(e){
		console.log('ssiiiii');
	}
	
}