cj.studio.mobile.diliweibo={
	render:function(){
		console.log('diliweibo');
	},
		showFilter:function(the){
		$("#afui").actionsheet(
                            [{
                                text: '全部',
                                cssClasses: 'red',
                                handler: function () {
                                   $(the).parent().siblings("a[name='selected']").text("全部");
                                }
                            }, {
                                text: '行人',
                                cssClasses: 'blue',
                                handler: function () {
                                    $(the).parent().siblings("a[name='selected']").text("行人");
                                }
                            }, {
                                text: '打车',
                                cssClasses: '',
                                handler: function () {
                                  $(the).parent().siblings("a[name='selected']").text("打车");
                                }
							
                            }, {
                                text: '美食',
                                cssClasses: '',
                                handler: function () {
                                    $(the).parent().siblings("a[name='selected']").text("美食");
                                }
							
							}, {
                                text: '休闲娱乐',
                                cssClasses: '',
                                handler: function () {
                                     $(the).parent().siblings("a[name='selected']").text("休闲娱乐");
                                }
							
							}, {
                                text: '地理微博',
                                cssClasses: '',
                                handler: function () {
                                     $(the).parent().siblings("a[name='selected']").text("地理微博");
                                }
							
							}, {
                                text: '酒店',
                                cssClasses: '',
                                handler: function () {
                                     $(the).parent().siblings("a[name='selected']").text("酒店");
                                }
							
							}, {
                                text: '丽人',
                                cssClasses: '',
                                handler: function () {
                                     $(the).parent().siblings("a[name='selected']").text("丽人");
                                }
							
							}, {
                                text: '购物',
                                cssClasses: '',
                                handler: function () {
                                     $(the).parent().siblings("a[name='selected']").text("购物");
                                }
							
							}, {
                                text: '旅游',
                                cssClasses: '',
                                handler: function () {
                                     $(the).parent().siblings("a[name='selected']").text("旅游");
                                }
							
							}, {
                                text: '亲子婚庆',
                                cssClasses: '',
                                handler: function () {
                                     $(the).parent().siblings("a[name='selected']").text("亲子婚庆");
                                }
							
							}]);	
	}
	
}