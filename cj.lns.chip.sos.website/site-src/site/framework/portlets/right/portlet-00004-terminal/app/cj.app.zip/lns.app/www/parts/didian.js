cj.studio.mobile.didian={
	render:function(){
		console.log('didian_kxsd');
	}
	
}